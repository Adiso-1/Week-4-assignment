const repeatStr = (n, string) => Array(n).fill(string).join('');
console.log(repeatStr(6, "I"));
console.log(repeatStr(5, "Hello"));