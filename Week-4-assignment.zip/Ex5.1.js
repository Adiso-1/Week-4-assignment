const trimmer = (string) => string.slice(1,string.length - 1);

console.log(trimmer("hello"));
console.log(trimmer("nice it works"));

